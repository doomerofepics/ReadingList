//
//  PictureController.swift
//  Reading List
//
//  Created by Mikhil Kiran on 6/18/19.
//  Copyright © 2019 Mikhil Kiran. All rights reserved.
//

import UIKit

class PictureController: UIViewController {
    let ImageArray = ["GRENINJA", "Pikachu", "Eevee", "TrollFace", "IndoorFireworks", "SatisfyingWineGlass", "SatisfyingSodaSetup"]
    
    @IBOutlet weak var hi: UIImageView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    
    
    @IBAction func buttonclick(_ sender: Any) {
        let image:Int = Int(arc4random_uniform(7))
        hi.image = UIImage (named: ImageArray[image])
    }
}
