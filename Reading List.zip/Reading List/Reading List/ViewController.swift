//
//  ViewController.swift
//  Reading List
//
//  Created by Mikhil Kiran on 6/18/19.
//  Copyright © 2019 Mikhil Kiran. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UITableViewDataSource, UITableViewDelegate {
    
    var books : [String] = []
    
    @IBOutlet weak var table: UITableView!
    @IBOutlet weak var TextArmadillo: UITextField!
    
    let strFileName = "readinglist.txt"
    let dir = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return books.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell1 = UITableViewCell(style: .default, reuseIdentifier: "cellID")
        cell1.textLabel?.text = books[indexPath.row]
        return cell1
    }
    
    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
        if (editingStyle == .delete){
            books.remove(at: indexPath.row)
            writeArrayToFile()
            table.reloadData()
        }
    }
    
    override func viewDidAppear(_ animated: Bool) {
        table.reloadData()
        readDataFromFile()
    }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        readDataFromFile()
        table.reloadData()
        // Do any additional setup after loading the view.
    }
    
    @IBAction func buttonclick(_ sender: Any) {
        if (TextArmadillo.text != "")  {
            books.append(TextArmadillo.text!)
            writeArrayToFile()
            TextArmadillo.text = ""
            table.reloadData()
        }
    }
    
    func readDataFromFile(){
        let fileURL = dir!.appendingPathComponent(strFileName)
        
        let fileManager = FileManager.default
        let pathComponent = dir?.appendingPathComponent(strFileName)
        let filePath = pathComponent!.path
        
        if fileManager.fileExists(atPath: filePath){
            books = NSMutableArray(contentsOf: fileURL) as! [String]
        } else {
            writeArrayToFile()
        }
    }
    
    func writeArrayToFile(){
        let fileURL = dir!.appendingPathComponent(strFileName)
        (books as NSArray).write(to: fileURL, atomically: true)
    }

}

